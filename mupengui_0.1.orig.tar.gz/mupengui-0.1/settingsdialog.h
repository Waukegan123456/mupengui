#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include <QDialog>
#include <QTextStream>
#include <QSettings>

namespace Ui {
class SettingsDialog;
}

class SettingsDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit SettingsDialog(QWidget *parent = 0);
    ~SettingsDialog();

public slots:
    //void on_radioWindowedFullscreen_toggled();
    void accept();

    
private:
    Ui::SettingsDialog *ui;
    QSettings MySettings;
    QString WINDOWED_FULLSCREEN = "WINDOWED";
};

#endif // SETTINGSDIALOG_H
