#include "settingsdialog.h"
#include "ui_settingsdialog.h"

SettingsDialog::SettingsDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SettingsDialog)
{
    ui->setupUi(this);
    //connect(ui->radioWindowed, SIGNAL(toggled(bool)), this, SLOT(on_radioWindowedFullscreen_toggled()));
    //connect(ui->radioFullscreen, SIGNAL(toggled(bool)), this, SLOT(on_radioWindowedFullscreen_toggled()));

    //WINDOWED_FULLSCREEN = "WINDOWED";

    if (MySettings.value(WINDOWED_FULLSCREEN).toString() == "WINDOWED") {
        ui->radioWindowed->setChecked(true);
    } else if (MySettings.value(WINDOWED_FULLSCREEN).toString() == "FULLSCREEN") {
        ui->radioFullscreen->setChecked(true);
    }

    this->setFixedSize(404, 266);

}

SettingsDialog::~SettingsDialog()
{
    delete ui;
}

/*
void SettingsDialog::on_radioWindowedFullscreen_toggled()
{
    //QTextStream out(stdout);
    //out << "Settings: " << MySettings.value(WINDOWED_FULLSCREEN).toString();




}
*/

void SettingsDialog::accept()
{
    //QTextStream out(stdout);
    //out << "Accept " << "ACCEPTED";

    if (ui->radioFullscreen->isChecked()) {
        MySettings.setValue(WINDOWED_FULLSCREEN, "FULLSCREEN");
    } else if (ui->radioWindowed->isChecked()) {
        MySettings.setValue(WINDOWED_FULLSCREEN, "WINDOWED");
    }

    this->close();
}


